import { NavLink, Navigate, Route, Routes } from "react-router-dom";
import { supabase } from "./lib/supabase";
import { useCrm } from "./lib/data";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Tracker from "./pages/Tracker";
import Employees, { EmployeeDetail } from "./pages/Employees";
import TrainingLog from "./pages/TrainingLog";
import Scorecards from "./pages/Scorecards";
import RolePlays from "./pages/RolePlays";
import Plan from "./pages/Plan";
import Modules from "./pages/Modules";
import MyTraining from "./pages/MyTraining";

const adminNav = [["/dashboard", "Dashboard"], ["/tracker", "Tracker"], ["/employees", "Employees"], ["/log", "Training log"],
  ["/scorecards", "Scorecards"], ["/roleplays", "Role-plays"], ["/plan", "30-day plan"], ["/modules", "Modules"]];

export default function App() {
  const { me, loading, error } = useCrm();
  if (loading) return <div className="boot">Loading...</div>;
  if (!me) return <Login />;
  const admin = me.isAdmin;
  const nav = admin ? adminNav : [["/my-training", "My training"]];
  return (
    <div className="shell">
      <aside className="side">
        <div className="brand"><b>SL Fastners</b><span>Training CRM</span></div>
        <nav>{nav.map(([to, label]) => <NavLink key={to} to={to} className={({ isActive }) => (isActive ? "active" : "")}>{label}</NavLink>)}</nav>
        <div className="side-foot">
          <p>{me.employee?.full_name ?? me.email}<small>{admin ? "Administrator" : "Employee"}</small></p>
          <button className="btn ghost light" onClick={() => supabase.auth.signOut()}>Sign out</button>
          <small>Prepared by Scaleup Business Consulting</small>
        </div>
      </aside>
      <main className="main">
        {error && <p className="error banner">Could not load some data: {error}. Check that supabase/schema.sql has been run.</p>}
        <Routes>
          {admin ? (<>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/tracker" element={<Tracker />} />
            <Route path="/employees" element={<Employees />} />
            <Route path="/employees/:id" element={<EmployeeDetail />} />
            <Route path="/log" element={<TrainingLog />} />
            <Route path="/scorecards" element={<Scorecards />} />
            <Route path="/roleplays" element={<RolePlays />} />
            <Route path="/plan" element={<Plan />} />
            <Route path="/modules" element={<Modules />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </>) : (<>
            <Route path="/my-training" element={<MyTraining />} />
            <Route path="*" element={<Navigate to="/my-training" replace />} />
          </>)}
        </Routes>
      </main>
    </div>
  );
}
