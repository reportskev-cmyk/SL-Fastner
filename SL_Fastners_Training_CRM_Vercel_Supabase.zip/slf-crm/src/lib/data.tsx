import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from "react";
import { supabase } from "./supabase";
import { CrmData, EMPTY, Employee } from "./crm";

export type Me = { userId: string; email: string; isAdmin: boolean; employee: Employee | null };
type Ctx = { me: Me | null; data: CrmData; loading: boolean; error: string | null; refresh: () => Promise<void> };
const DataCtx = createContext<Ctx>({ me: null, data: EMPTY, loading: true, error: null, refresh: async () => {} });
export const useCrm = () => useContext(DataCtx);

export function DataProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [data, setData] = useState<CrmData>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) { setMe(null); setData(EMPTY); setLoading(false); return; }
    const [roles, emp, e, m, l, s, r, p] = await Promise.all([
      supabase.from("user_roles").select("role").eq("user_id", u.user.id),
      supabase.from("employees").select("*").eq("user_id", u.user.id).maybeSingle(),
      supabase.from("employees").select("*").order("full_name"),
      supabase.from("modules").select("*").order("sort"),
      supabase.from("training_logs").select("*").order("session_date", { ascending: false }).limit(5000),
      supabase.from("scorecards").select("*").order("eval_date", { ascending: false }),
      supabase.from("roleplays").select("*").order("rp_date", { ascending: false }),
      supabase.from("plan_progress").select("*"),
    ]);
    const firstErr = [roles, e, m, l, s, r, p].find((x) => x.error)?.error;
    setError(firstErr ? firstErr.message : null);
    setMe({
      userId: u.user.id, email: u.user.email ?? "",
      isAdmin: (roles.data ?? []).some((x: { role: string }) => x.role === "admin"),
      employee: (emp.data as Employee) ?? null,
    });
    setData({
      employees: (e.data ?? []) as CrmData["employees"], modules: (m.data ?? []) as CrmData["modules"],
      logs: (l.data ?? []) as CrmData["logs"], scorecards: (s.data ?? []) as CrmData["scorecards"],
      roleplays: (r.data ?? []) as CrmData["roleplays"], plan: (p.data ?? []) as CrmData["plan"],
    });
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    const { data: sub } = supabase.auth.onAuthStateChange(() => { setTimeout(load, 0); });
    return () => sub.subscription.unsubscribe();
  }, [load]);

  return <DataCtx.Provider value={{ me, data, loading, error, refresh: load }}>{children}</DataCtx.Provider>;
}
