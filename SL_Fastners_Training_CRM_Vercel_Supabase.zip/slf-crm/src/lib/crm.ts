export type Employee = {
  id: string; user_id: string | null; emp_code: string | null; full_name: string; email: string;
  job_role: string | null; department: string | null; region: string | null; reporting_manager: string | null;
  mobile: string | null; joining_date: string | null; batch: string | null; target_date: string | null; is_demo: boolean;
};
export type Module = {
  id: string; sort: number; title: string; short_name: string; phase: string | null;
  key_output: string | null; assessment: string | null; pass_mark: number;
};
export type LogStatus = "Scheduled" | "In Progress" | "Completed" | "Missed - Reschedule";
export type TrainingLog = {
  id: string; employee_id: string; module_id: string; session_date: string; trainer: string | null; mode: string;
  attended: boolean; status: LogStatus; score: number | null; remarks: string | null;
};
export type Scorecard = {
  id: string; employee_id: string; eval_date: string; evaluator: string | null; scores: number[]; coaching_action: string | null;
};
export type Roleplay = {
  id: string; employee_id: string; rp_date: string; scenario: string; observer: string | null; checks: boolean[]; remarks: string | null;
};
export type PlanStatus = "Not Started" | "In Progress" | "Done";
export type PlanProgress = { id: string; employee_id: string; period: number; status: PlanStatus; notes: string | null };
export type CrmData = {
  employees: Employee[]; modules: Module[]; logs: TrainingLog[];
  scorecards: Scorecard[]; roleplays: Roleplay[]; plan: PlanProgress[];
};
export const EMPTY: CrmData = { employees: [], modules: [], logs: [], scorecards: [], roleplays: [], plan: [] };

export const LOG_STATUSES: LogStatus[] = ["Scheduled", "In Progress", "Completed", "Missed - Reschedule"];
export const MODES = ["Classroom", "Field coaching", "Online", "Self-study"];
export const ROLES = ["Sales Executive", "Sales Coordinator", "Territory Manager", "Sales Leader"];
export const SCENARIOS = ["Price pressure", "Loyal to incumbent", "Technical complaint", "Credit demand",
  "No urgency", "Distributor margin", "Unfamiliar brand", "Urgent supply"];
export const COMPETENCIES = ["Product and application understanding", "Opening and rapport",
  "Listening and acknowledgement", "Questioning and qualification", "Technical accuracy / escalation",
  "Value selling and negotiation", "Closing for a next step", "Follow-up and CRM discipline"];
export const RATING_GUIDE = ["Needs significant coaching", "Developing", "Meets expectations", "Strong", "Role model"];
export const RP_CHECKS = ["Listened without interrupting", "Acknowledged the buyer's concern",
  "Asked at least 2 useful diagnostic questions", "Avoided unsupported claims and unauthorised commitments",
  "Explained a relevant solution or next action", "Confirmed owner and date"];
export const PLAN_PERIODS = [
  { days: "Days 1-5", action: "Learn core SKUs, approved specifications, catalogue, price/credit rules and escalation contacts.", check: "Short product knowledge quiz." },
  { days: "Days 6-10", action: "Practise the 5-step method and commercial objection scripts.", check: "Two observed role-plays per salesperson." },
  { days: "Days 11-15", action: "Use the application discovery checklist on customer calls and visits.", check: "Review five completed customer profiles." },
  { days: "Days 16-20", action: "Run sample and quotation follow-ups with agreed next steps.", check: "Review ageing samples and quotations." },
  { days: "Days 21-25", action: "Record objections and lost-order reasons consistently.", check: "Audit objection tracker and CRM notes." },
  { days: "Days 26-30", action: "Review conversions, feedback and individual coaching priorities.", check: "Scorecard, action plan and next-month targets." },
];
export const PLAN_STATUSES: PlanStatus[] = ["Not Started", "In Progress", "Done"];

export type CellStatus = "Completed" | "In Progress" | "Scheduled" | "Missed" | "Not Started";
export const CELL_STATUSES: CellStatus[] = ["Completed", "In Progress", "Scheduled", "Missed", "Not Started"];

export function cellStatus(logs: TrainingLog[], empId: string, modId: string): CellStatus {
  const mine = logs.filter((l) => l.employee_id === empId && l.module_id === modId);
  if (mine.some((l) => l.status === "Completed")) return "Completed";
  if (mine.some((l) => l.status === "In Progress")) return "In Progress";
  if (mine.some((l) => l.status === "Scheduled")) return "Scheduled";
  if (mine.some((l) => l.status === "Missed - Reschedule")) return "Missed";
  return "Not Started";
}

export function result(score: number | null, pass: number): "Pass" | "Re-assess" | "" {
  if (score === null || score === undefined) return "";
  return Number(score) >= pass ? "Pass" : "Re-assess";
}

export type Summary = {
  employee: Employee; cells: Record<string, CellStatus>; completed: number; pct: number;
  overall: "Completed" | "In Progress" | "Not Started"; overdue: boolean;
  lastActivity: string | null; avgScore: number | null; reassess: number;
};

export function summarize(emp: Employee, modules: Module[], logs: TrainingLog[]): Summary {
  const cells: Record<string, CellStatus> = {};
  let completed = 0, inProg = 0, reassess = 0;
  for (const m of modules) {
    const c = cellStatus(logs, emp.id, m.id);
    cells[m.id] = c;
    if (c === "Completed") completed++;
    if (c === "In Progress") inProg++;
    const done = logs.filter((l) => l.employee_id === emp.id && l.module_id === m.id && l.status === "Completed" && l.score !== null);
    if (done.length && Math.max(...done.map((l) => Number(l.score))) < m.pass_mark) reassess++;
  }
  const mine = logs.filter((l) => l.employee_id === emp.id);
  const scores = mine.filter((l) => l.status === "Completed" && l.score !== null).map((l) => Number(l.score));
  const overall = modules.length && completed === modules.length ? "Completed" : completed + inProg > 0 ? "In Progress" : "Not Started";
  const today = new Date().toISOString().slice(0, 10);
  return {
    employee: emp, cells, completed, pct: modules.length ? completed / modules.length : 0, overall,
    overdue: overall !== "Completed" && !!emp.target_date && emp.target_date < today,
    lastActivity: mine.length ? mine.map((l) => l.session_date).sort().slice(-1)[0] : null,
    avgScore: scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : null,
    reassess,
  };
}

export const scoreTotal = (s: number[]) => s.reduce((a, b) => a + b, 0);
export const needsCoaching = (s: number[]) => s.some((x) => x <= 2);
export const rpScore = (r: Roleplay) => r.checks.filter(Boolean).length;
export const planPct = (rows: PlanProgress[]) => rows.filter((r) => r.status === "Done").length / 6;

export function fmt(d?: string | null) {
  if (!d) return "-";
  return new Date(d + "T00:00:00").toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

export function downloadCsv(name: string, rows: (string | number | null)[][]) {
  const esc = (v: string | number | null) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const blob = new Blob([rows.map((r) => r.map(esc).join(",")).join("\n")], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name; a.click(); URL.revokeObjectURL(a.href);
}
