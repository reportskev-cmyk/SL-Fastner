import { useMemo, useState } from "react";
import { useCrm } from "../lib/data";
import { COMPETENCIES, Employee, PLAN_PERIODS, fmt, needsCoaching, planPct, result, rpScore, scoreTotal, summarize } from "../lib/crm";
import { Modal, Pill, Ring } from "./ui";
import LogForm from "./LogForm";

export default function EmployeeView({ employee, canEdit }: { employee: Employee; canEdit: boolean }) {
  const { data } = useCrm();
  const [logOpen, setLogOpen] = useState(false);
  const [initial, setInitial] = useState<{ employee_id: string; module_id?: string } | null>(null);
  const [cert, setCert] = useState(false);

  const s = useMemo(() => summarize(employee, data.modules, data.logs), [employee, data]);
  const card = data.scorecards.find((x) => x.employee_id === employee.id);
  const rps = data.roleplays.filter((x) => x.employee_id === employee.id);
  const plan = data.plan.filter((x) => x.employee_id === employee.id);
  const rpAvg = rps.length ? rps.reduce((a, r) => a + rpScore(r), 0) / rps.length : null;

  return (
    <div className="stack">
      <section className="panel profile">
        <Ring pct={s.pct} />
        <div className="grow">
          <h2 className="name">{employee.full_name}</h2>
          <p className="muted">
            {[employee.job_role, employee.region, employee.reporting_manager && `Reports to ${employee.reporting_manager}`].filter(Boolean).join(", ")}
          </p>
          <div className="chips">
            <Pill status={s.overall} />
            {s.overdue && <Pill status="Overdue" />}
            <span className="chip">{s.completed} of {data.modules.length} modules complete</span>
            {employee.batch && <span className="chip">{employee.batch}</span>}
            <span className="chip">Target: {fmt(employee.target_date)}</span>
          </div>
        </div>
        <div className="actions col">
          {canEdit && <button className="btn primary" onClick={() => { setInitial({ employee_id: employee.id }); setLogOpen(true); }}>Add training record</button>}
          {s.pct === 1 && <button className="btn" onClick={() => setCert(true)}>View certificate</button>}
        </div>
      </section>

      <section className="panel">
        <h3>Modules</h3>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Module</th><th>Status</th><th>Last session</th><th>Best score</th><th>Result</th>{canEdit && <th />}</tr></thead>
            <tbody>
              {data.modules.map((m) => {
                const mine = data.logs.filter((l) => l.employee_id === employee.id && l.module_id === m.id);
                const scores = mine.filter((l) => l.score !== null).map((l) => Number(l.score));
                const best = scores.length ? Math.max(...scores) : null;
                return (
                  <tr key={m.id}>
                    <td><strong>{m.id}</strong> {m.short_name}</td>
                    <td><Pill status={s.cells[m.id]} /></td>
                    <td>{fmt(mine.map((l) => l.session_date).sort().slice(-1)[0])}</td>
                    <td>{best === null ? "-" : `${best}%`}</td>
                    <td>{best === null ? "-" : <Pill status={result(best, m.pass_mark)} />}</td>
                    {canEdit && <td><button className="btn small ghost" onClick={() => { setInitial({ employee_id: employee.id, module_id: m.id }); setLogOpen(true); }}>Update</button></td>}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      <div className="two-col">
        <section className="panel">
          <h3>Manager scorecard</h3>
          {card ? (
            <>
              <p className="muted">Evaluated {fmt(card.eval_date)}{card.evaluator ? ` by ${card.evaluator}` : ""}. Total {scoreTotal(card.scores)} of 40.</p>
              <ul className="bars">
                {COMPETENCIES.map((c, i) => (
                  <li key={c}><span>{c}</span><div className="bar"><i style={{ width: `${card.scores[i] * 20}%` }} className={card.scores[i] <= 2 ? "low" : ""} /></div><b>{card.scores[i]}</b></li>
                ))}
              </ul>
              {needsCoaching(card.scores) && <p className="callout">Coaching action: {card.coaching_action || "Not recorded yet"}</p>}
            </>
          ) : <p className="muted">No scorecard yet.</p>}
        </section>
        <section className="panel">
          <h3>30-day plan</h3>
          <p className="muted">{Math.round(planPct(plan) * 100)}% complete</p>
          <ul className="plan-list">
            {PLAN_PERIODS.map((p, i) => {
              const st = plan.find((x) => x.period === i + 1)?.status ?? "Not Started";
              return <li key={p.days}><span><b>{p.days}</b> {p.action}</span><Pill status={st} /></li>;
            })}
          </ul>
          <h3 className="space-top">Role-plays</h3>
          <p className="muted">{rps.length ? `${rps.length} logged, average ${rpAvg!.toFixed(1)} of 6` : "None logged yet."}</p>
        </section>
      </div>

      <LogForm open={logOpen} onClose={() => setLogOpen(false)} initial={initial} />
      <Modal open={cert} onClose={() => setCert(false)} title="Certificate of completion" wide>
        <div className="cert">
          <p className="cert-top">SL Fastners</p>
          <h2>Certificate of completion</h2>
          <p>This certifies that</p>
          <p className="cert-name">{employee.full_name}</p>
          <p>has completed all {data.modules.length} modules of the<br /><b>Sales Objection Handling and Conversion programme</b></p>
          <p className="muted">Issued {fmt(new Date().toISOString().slice(0, 10))}. Prepared by Scaleup Business Consulting.</p>
        </div>
        <div className="form-actions"><span className="grow" /><button className="btn primary" onClick={() => window.print()}>Print certificate</button></div>
      </Modal>
    </div>
  );
}
