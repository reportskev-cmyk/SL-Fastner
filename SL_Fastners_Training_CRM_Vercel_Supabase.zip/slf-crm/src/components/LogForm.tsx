import { FormEvent, useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import { useCrm } from "../lib/data";
import { LOG_STATUSES, MODES, TrainingLog } from "../lib/crm";
import { Modal } from "./ui";

type Props = { open: boolean; onClose: () => void; initial?: Partial<TrainingLog> | null };
const today = () => new Date().toISOString().slice(0, 10);

export default function LogForm({ open, onClose, initial }: Props) {
  const { data, refresh } = useCrm();
  const [f, setF] = useState<Partial<TrainingLog>>({});
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (open) {
      setErr("");
      setF({ session_date: today(), mode: "Classroom", attended: true, status: "Scheduled", trainer: "", ...initial });
    }
  }, [open, initial]);

  const set = (k: keyof TrainingLog, v: unknown) => setF((p) => ({ ...p, [k]: v }));

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!f.employee_id || !f.module_id) { setErr("Choose an employee and a module."); return; }
    setBusy(true);
    const row = {
      employee_id: f.employee_id, module_id: f.module_id, session_date: f.session_date, trainer: f.trainer || null,
      mode: f.mode, attended: f.status === "Missed - Reschedule" ? false : f.attended, status: f.status,
      score: f.score === null || f.score === undefined || (f.score as unknown) === "" ? null : Number(f.score),
      remarks: f.remarks || null,
    };
    const { error } = f.id ? await supabase.from("training_logs").update(row).eq("id", f.id) : await supabase.from("training_logs").insert(row);
    setBusy(false);
    if (error) { setErr(error.message); return; }
    await refresh(); onClose();
  }

  async function remove() {
    if (!f.id || !confirm("Delete this training record?")) return;
    const { error } = await supabase.from("training_logs").delete().eq("id", f.id);
    if (error) { setErr(error.message); return; }
    await refresh(); onClose();
  }

  return (
    <Modal open={open} onClose={onClose} title={f.id ? "Edit training record" : "Add training record"}>
      <form onSubmit={save} className="form-grid">
        <label>Employee
          <select value={f.employee_id ?? ""} onChange={(e) => set("employee_id", e.target.value)} required>
            <option value="">Select employee</option>
            {data.employees.map((e) => <option key={e.id} value={e.id}>{e.full_name}{e.emp_code ? ` (${e.emp_code})` : ""}</option>)}
          </select>
        </label>
        <label>Module
          <select value={f.module_id ?? ""} onChange={(e) => set("module_id", e.target.value)} required>
            <option value="">Select module</option>
            {data.modules.map((m) => <option key={m.id} value={m.id}>{m.id} - {m.short_name}</option>)}
          </select>
        </label>
        <label>Status
          <select value={f.status} onChange={(e) => set("status", e.target.value)}>
            {LOG_STATUSES.map((s) => <option key={s}>{s}</option>)}
          </select>
        </label>
        <label>Date<input type="date" value={f.session_date ?? ""} onChange={(e) => set("session_date", e.target.value)} required /></label>
        <label>Trainer / facilitator<input value={f.trainer ?? ""} onChange={(e) => set("trainer", e.target.value)} /></label>
        <label>Mode
          <select value={f.mode} onChange={(e) => set("mode", e.target.value)}>{MODES.map((m) => <option key={m}>{m}</option>)}</select>
        </label>
        <label>Assessment score (%)
          <input type="number" min={0} max={100} step="1" value={f.score ?? ""} onChange={(e) => set("score", e.target.value === "" ? null : Number(e.target.value))} />
        </label>
        <label className="check"><input type="checkbox" checked={!!f.attended} onChange={(e) => set("attended", e.target.checked)} /> Attended</label>
        <label className="full">Remarks<textarea rows={2} value={f.remarks ?? ""} onChange={(e) => set("remarks", e.target.value)} /></label>
        {err && <p className="error full">{err}</p>}
        <div className="form-actions full">
          {f.id && <button type="button" className="btn danger" onClick={remove}>Delete</button>}
          <span className="grow" />
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn primary" disabled={busy}>{busy ? "Saving..." : "Save record"}</button>
        </div>
      </form>
    </Modal>
  );
}
