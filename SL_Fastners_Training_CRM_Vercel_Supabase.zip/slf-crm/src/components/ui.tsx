import { ReactNode } from "react";
import { CellStatus } from "../lib/crm";

export const STATUS_CLASS: Record<string, string> = {
  Completed: "s-done", "In Progress": "s-prog", Scheduled: "s-sched", Missed: "s-miss",
  "Missed - Reschedule": "s-miss", "Not Started": "s-none", Done: "s-done", Overdue: "s-miss",
  Pass: "s-done", "Re-assess": "s-miss",
};
export const Pill = ({ status }: { status: string }) => <span className={`pill ${STATUS_CLASS[status] ?? "s-none"}`}>{status}</span>;

export function PageHead({ title, sub, children }: { title: string; sub?: string; children?: ReactNode }) {
  return (
    <header className="page-head">
      <div><h1>{title}</h1>{sub && <p>{sub}</p>}</div>
      <div className="actions">{children}</div>
    </header>
  );
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  if (!open) return null;
  return (
    <div className="overlay" onMouseDown={onClose}>
      <div className={`modal ${wide ? "wide" : ""}`} role="dialog" aria-label={title} onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-head"><h2>{title}</h2><button className="icon-btn" onClick={onClose} aria-label="Close">x</button></div>
        {children}
      </div>
    </div>
  );
}

export const Empty = ({ title, text, children }: { title: string; text: string; children?: ReactNode }) => (
  <div className="empty"><h3>{title}</h3><p>{text}</p>{children}</div>
);

export function Ring({ pct, size = 112 }: { pct: number; size?: number }) {
  const r = size / 2 - 9, c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label={`${Math.round(pct * 100)} percent complete`}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#DDE1E8" strokeWidth="10" />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#C55A11" strokeWidth="10" strokeLinecap="round"
        strokeDasharray={`${c * pct} ${c}`} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      <text x="50%" y="52%" textAnchor="middle" dominantBaseline="middle" className="ring-text">{Math.round(pct * 100)}%</text>
    </svg>
  );
}

export const Rivet = ({ status, title, onClick }: { status: CellStatus; title: string; onClick?: () => void }) => (
  <button className={`rivet ${STATUS_CLASS[status]}`} title={title} aria-label={title} onClick={onClick} />
);
