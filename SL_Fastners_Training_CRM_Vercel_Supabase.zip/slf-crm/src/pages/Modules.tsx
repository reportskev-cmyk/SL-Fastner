import { useState } from "react";
import { supabase } from "../lib/supabase";
import { useCrm } from "../lib/data";
import { Module } from "../lib/crm";
import { PageHead } from "../components/ui";

export default function Modules() {
  const { data, refresh } = useCrm();
  const [edits, setEdits] = useState<Record<string, Partial<Module>>>({});
  const [msg, setMsg] = useState("");
  const val = <K extends keyof Module>(m: Module, k: K) => (edits[m.id]?.[k] ?? m[k]) as Module[K];
  const ch = (id: string, k: keyof Module, v: string | number) => setEdits((p) => ({ ...p, [id]: { ...p[id], [k]: v } }));
  async function save(m: Module) {
    const { error } = await supabase.from("modules").update(edits[m.id]).eq("id", m.id);
    setMsg(error ? error.message : `${m.id} saved`);
    if (!error) { setEdits((p) => { const n = { ...p }; delete n[m.id]; return n; }); await refresh(); }
  }
  return (
    <>
      <PageHead title="Modules" sub="The 13 modules from the training manual. Pass marks decide whether a score shows Pass or Re-assess." />
      {msg && <p className="muted">{msg}</p>}
      <div className="table-wrap"><table>
        <thead><tr><th>ID</th><th>Module</th><th>Phase</th><th>Key output</th><th>Assessment method</th><th>Pass mark %</th><th /></tr></thead>
        <tbody>{data.modules.map((m) => (
          <tr key={m.id}><td><b>{m.id}</b></td><td>{m.title}</td><td>{m.phase}</td><td>{m.key_output}</td>
            <td><input value={val(m, "assessment") ?? ""} onChange={(e) => ch(m.id, "assessment", e.target.value)} /></td>
            <td><input className="num" type="number" min={0} max={100} value={val(m, "pass_mark")} onChange={(e) => ch(m.id, "pass_mark", Number(e.target.value))} /></td>
            <td>{edits[m.id] && <button className="btn small primary" onClick={() => save(m)}>Save</button>}</td></tr>))}</tbody></table></div>
    </>
  );
}
