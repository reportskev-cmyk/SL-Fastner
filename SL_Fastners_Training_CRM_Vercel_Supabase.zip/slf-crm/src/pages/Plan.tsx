import { supabase } from "../lib/supabase";
import { useCrm } from "../lib/data";
import { Empty, PageHead, Pill } from "../components/ui";
import { PLAN_PERIODS, PLAN_STATUSES, PlanStatus, planPct } from "../lib/crm";

export default function Plan() {
  const { data, refresh } = useCrm();
  async function setStatus(employee_id: string, period: number, status: PlanStatus) {
    await supabase.from("plan_progress").upsert({ employee_id, period, status }, { onConflict: "employee_id,period" });
    await refresh();
  }
  return (
    <>
      <PageHead title="30-day plan" sub="Six five-day periods. Update each employee's status as the team action is completed." />
      {!data.employees.length ? <Empty title="No employees yet" text="Add employees to track their 30-day plan." /> : (
        <div className="table-wrap"><table>
          <thead><tr><th>Employee</th>{PLAN_PERIODS.map((p) => <th key={p.days} className="plan-h"><b>{p.days}</b><small>{p.action}</small><small className="chk">Manager: {p.check}</small></th>)}<th>Complete</th></tr></thead>
          <tbody>{data.employees.map((e) => {
            const rows = data.plan.filter((p) => p.employee_id === e.id);
            return (<tr key={e.id}><td>{e.full_name}<small>{e.job_role}</small></td>
              {PLAN_PERIODS.map((p, i) => {
                const st = rows.find((r) => r.period === i + 1)?.status ?? "Not Started";
                return <td key={p.days}><select className={`sel ${st === "Done" ? "s-done" : st === "In Progress" ? "s-prog" : ""}`} value={st} onChange={(ev) => setStatus(e.id, i + 1, ev.target.value as PlanStatus)}>
                  {PLAN_STATUSES.map((s) => <option key={s}>{s}</option>)}</select></td>;
              })}
              <td><Pill status={planPct(rows) === 1 ? "Completed" : planPct(rows) > 0 ? "In Progress" : "Not Started"} /> <small>{Math.round(planPct(rows) * 100)}%</small></td></tr>);
          })}</tbody></table></div>
      )}
    </>
  );
}
