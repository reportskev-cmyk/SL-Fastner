import { FormEvent, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useCrm } from "../lib/data";
import { Employee, ROLES, fmt, summarize } from "../lib/crm";
import { Empty, Modal, PageHead, Pill } from "../components/ui";
import EmployeeView from "../components/EmployeeView";

type Draft = Partial<Employee>;

function EmployeeForm({ open, onClose, initial }: { open: boolean; onClose: () => void; initial: Draft | null }) {
  const { refresh } = useCrm();
  const [f, setF] = useState<Draft>({});
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) { setF({ ...initial }); setErr(""); } }, [open, initial]);
  const set = (k: keyof Employee, v: string) => setF((p) => ({ ...p, [k]: v }));
  async function save(e: FormEvent) {
    e.preventDefault(); setBusy(true);
    const row = {
      emp_code: f.emp_code || null, full_name: f.full_name, email: (f.email ?? "").trim().toLowerCase(), job_role: f.job_role || null,
      department: f.department || null, region: f.region || null, reporting_manager: f.reporting_manager || null, mobile: f.mobile || null,
      joining_date: f.joining_date || null, batch: f.batch || null, target_date: f.target_date || null,
    };
    const { error } = f.id ? await supabase.from("employees").update(row).eq("id", f.id) : await supabase.from("employees").insert(row);
    setBusy(false);
    if (error) { setErr(error.message.includes("duplicate") ? "An employee with this email already exists." : error.message); return; }
    await refresh(); onClose();
  }
  return (
    <Modal open={open} onClose={onClose} title={f.id ? "Edit employee" : "Add employee"}>
      <form className="form-grid" onSubmit={save}>
        <label>Full name<input value={f.full_name ?? ""} onChange={(e) => set("full_name", e.target.value)} required /></label>
        <label>Employee ID<input value={f.emp_code ?? ""} onChange={(e) => set("emp_code", e.target.value)} /></label>
        <label>Work email (used to sign in)<input type="email" value={f.email ?? ""} onChange={(e) => set("email", e.target.value)} required /></label>
        <label>Mobile<input value={f.mobile ?? ""} onChange={(e) => set("mobile", e.target.value)} /></label>
        <label>Role<input list="roles" value={f.job_role ?? ""} onChange={(e) => set("job_role", e.target.value)} />
          <datalist id="roles">{ROLES.map((r) => <option key={r} value={r} />)}</datalist></label>
        <label>Department<input value={f.department ?? ""} onChange={(e) => set("department", e.target.value)} /></label>
        <label>Region<input value={f.region ?? ""} onChange={(e) => set("region", e.target.value)} /></label>
        <label>Reporting manager<input value={f.reporting_manager ?? ""} onChange={(e) => set("reporting_manager", e.target.value)} /></label>
        <label>Joining date<input type="date" value={f.joining_date ?? ""} onChange={(e) => set("joining_date", e.target.value)} /></label>
        <label>Training batch<input value={f.batch ?? ""} onChange={(e) => set("batch", e.target.value)} /></label>
        <label>Target completion date<input type="date" value={f.target_date ?? ""} onChange={(e) => set("target_date", e.target.value)} /></label>
        {err && <p className="error full">{err}</p>}
        <div className="form-actions full"><span className="grow" /><button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn primary" disabled={busy}>{busy ? "Saving..." : "Save employee"}</button></div>
      </form>
    </Modal>
  );
}

export default function Employees() {
  const { data, refresh } = useCrm();
  const [q, setQ] = useState(""); const [open, setOpen] = useState(false); const [initial, setInitial] = useState<Draft | null>(null);
  const sums = useMemo(() => data.employees.map((e) => summarize(e, data.modules, data.logs)), [data]);
  const rows = sums.filter((s) => !q || `${s.employee.full_name} ${s.employee.emp_code} ${s.employee.email}`.toLowerCase().includes(q.toLowerCase()));

  async function remove(e: Employee) {
    if (!confirm(`Delete ${e.full_name} and all their training records?`)) return;
    await supabase.from("employees").delete().eq("id", e.id); await refresh();
  }
  return (
    <>
      <PageHead title="Employees" sub="Employees sign in with the email you register here.">
        <input placeholder="Search" value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn primary" onClick={() => { setInitial({}); setOpen(true); }}>Add employee</button>
      </PageHead>
      {!data.employees.length ? <Empty title="No employees yet" text="Add the first salesperson to start tracking." /> : (
        <div className="table-wrap"><table>
          <thead><tr><th>Name</th><th>ID</th><th>Role</th><th>Region</th><th>Batch</th><th>Target</th><th>Progress</th><th>Account</th><th /></tr></thead>
          <tbody>{rows.map((s) => (
            <tr key={s.employee.id}>
              <td><Link to={`/employees/${s.employee.id}`}>{s.employee.full_name}</Link><small>{s.employee.email}</small></td>
              <td>{s.employee.emp_code ?? "-"}</td><td>{s.employee.job_role ?? "-"}</td><td>{s.employee.region ?? "-"}</td>
              <td>{s.employee.batch ?? "-"}</td><td>{fmt(s.employee.target_date)}</td>
              <td><Pill status={s.overall} /> <small>{Math.round(s.pct * 100)}%</small></td>
              <td>{s.employee.user_id ? "Signed up" : "Not yet"}</td>
              <td className="row-actions"><button className="btn small ghost" onClick={() => { setInitial(s.employee); setOpen(true); }}>Edit</button>
                <button className="btn small danger-ghost" onClick={() => remove(s.employee)}>Delete</button></td>
            </tr>))}</tbody></table></div>
      )}
      <EmployeeForm open={open} onClose={() => setOpen(false)} initial={initial} />
    </>
  );
}

export function EmployeeDetail() {
  const { id } = useParams(); const nav = useNavigate(); const { data } = useCrm();
  const emp = data.employees.find((e) => e.id === id);
  if (!emp) return <Empty title="Employee not found" text="This record may have been deleted."><button className="btn" onClick={() => nav("/employees")}>Back to employees</button></Empty>;
  return (<><PageHead title="Employee detail"><Link className="btn" to="/employees">Back to employees</Link></PageHead><EmployeeView employee={emp} canEdit /></>);
}
