import { useMemo, useState } from "react";
import { useCrm } from "../lib/data";
import { LOG_STATUSES, TrainingLog as Log, fmt, result } from "../lib/crm";
import { Empty, PageHead, Pill } from "../components/ui";
import LogForm from "../components/LogForm";

export default function TrainingLog() {
  const { data } = useCrm();
  const [emp, setEmp] = useState(""); const [mod, setMod] = useState(""); const [st, setSt] = useState("");
  const [open, setOpen] = useState(false); const [initial, setInitial] = useState<Partial<Log> | null>(null);
  const name = (id: string) => data.employees.find((e) => e.id === id)?.full_name ?? "-";
  const rows = useMemo(() => data.logs.filter((l) => (!emp || l.employee_id === emp) && (!mod || l.module_id === mod) && (!st || l.status === st)), [data, emp, mod, st]);
  return (
    <>
      <PageHead title="Training log" sub="One row per training event. The tracker and dashboard update from these records.">
        <button className="btn primary" onClick={() => { setInitial(null); setOpen(true); }}>Add training record</button>
      </PageHead>
      <div className="filters">
        <select value={emp} onChange={(e) => setEmp(e.target.value)}><option value="">All employees</option>{data.employees.map((e) => <option key={e.id} value={e.id}>{e.full_name}</option>)}</select>
        <select value={mod} onChange={(e) => setMod(e.target.value)}><option value="">All modules</option>{data.modules.map((m) => <option key={m.id} value={m.id}>{m.id} {m.short_name}</option>)}</select>
        <select value={st} onChange={(e) => setSt(e.target.value)}><option value="">Any status</option>{LOG_STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
      </div>
      {!rows.length ? <Empty title="No training records" text="Add a record after each session or assessment." /> : (
        <div className="table-wrap"><table>
          <thead><tr><th>Date</th><th>Employee</th><th>Module</th><th>Status</th><th>Mode</th><th>Trainer</th><th>Score</th><th>Result</th><th>Remarks</th><th /></tr></thead>
          <tbody>{rows.map((l) => {
            const m = data.modules.find((x) => x.id === l.module_id); const r = m ? result(l.score, m.pass_mark) : "";
            return (<tr key={l.id}><td>{fmt(l.session_date)}</td><td>{name(l.employee_id)}</td><td>{l.module_id} {m?.short_name}</td><td><Pill status={l.status} /></td>
              <td>{l.mode}</td><td>{l.trainer ?? "-"}</td><td>{l.score === null ? "-" : `${l.score}%`}</td><td>{r ? <Pill status={r} /> : "-"}</td><td>{l.remarks ?? ""}</td>
              <td><button className="btn small ghost" onClick={() => { setInitial(l); setOpen(true); }}>Edit</button></td></tr>);
          })}</tbody></table></div>
      )}
      <LogForm open={open} onClose={() => setOpen(false)} initial={initial} />
    </>
  );
}
