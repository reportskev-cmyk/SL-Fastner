import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useCrm } from "../lib/data";
import { CELL_STATUSES, ROLES, TrainingLog, downloadCsv, fmt, summarize } from "../lib/crm";
import { Empty, PageHead, Pill, Rivet } from "../components/ui";
import LogForm from "../components/LogForm";

export default function Tracker() {
  const { data } = useCrm();
  const [q, setQ] = useState(""); const [role, setRole] = useState(""); const [batch, setBatch] = useState("");
  const [status, setStatus] = useState(""); const [od, setOd] = useState(false);
  const [open, setOpen] = useState(false);
  const [initial, setInitial] = useState<Partial<TrainingLog> | null>(null);

  const sums = useMemo(() => data.employees.map((e) => summarize(e, data.modules, data.logs)), [data]);
  const batches = [...new Set(data.employees.map((e) => e.batch).filter(Boolean))] as string[];
  const rows = sums.filter((s) =>
    (!q || s.employee.full_name.toLowerCase().includes(q.toLowerCase())) && (!role || s.employee.job_role === role) &&
    (!batch || s.employee.batch === batch) && (!status || s.overall === status) && (!od || s.overdue));

  function exportCsv() {
    downloadCsv("training-tracker.csv", [
      ["Emp ID", "Name", "Role", "Region", "Batch", "Target date", ...data.modules.map((m) => m.id), "Completed", "% complete", "Overall", "Overdue", "Last activity", "Avg score"],
      ...rows.map((s) => [s.employee.emp_code, s.employee.full_name, s.employee.job_role, s.employee.region, s.employee.batch, s.employee.target_date,
        ...data.modules.map((m) => s.cells[m.id]), s.completed, Math.round(s.pct * 100), s.overall, s.overdue ? "Overdue" : "", s.lastActivity, s.avgScore === null ? "" : Math.round(s.avgScore)]),
    ]);
  }

  return (
    <>
      <PageHead title="Tracker" sub="Every employee against every module. Select a rivet to add or update a record.">
        <button className="btn" onClick={exportCsv}>Export CSV</button>
      </PageHead>
      <div className="filters">
        <input placeholder="Search name" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={role} onChange={(e) => setRole(e.target.value)}><option value="">All roles</option>{ROLES.map((r) => <option key={r}>{r}</option>)}</select>
        <select value={batch} onChange={(e) => setBatch(e.target.value)}><option value="">All batches</option>{batches.map((b) => <option key={b}>{b}</option>)}</select>
        <select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">Any status</option>{["Completed", "In Progress", "Not Started"].map((s) => <option key={s}>{s}</option>)}</select>
        <label className="check"><input type="checkbox" checked={od} onChange={(e) => setOd(e.target.checked)} /> Overdue only</label>
      </div>
      <div className="legend">{CELL_STATUSES.map((s) => <Pill key={s} status={s} />)}</div>
      {!data.employees.length ? <Empty title="No employees yet" text="Add employees first, then record their training."><Link className="btn primary" to="/employees">Add employees</Link></Empty> : (
        <div className="table-wrap tracker">
          <table>
            <thead><tr><th className="sticky">Employee</th>{data.modules.map((m) => <th key={m.id} title={m.title} className="mod">{m.id}<small>{m.short_name}</small></th>)}
              <th>Done</th><th>Status</th><th>Last activity</th><th>Avg score</th></tr></thead>
            <tbody>
              {rows.map((s) => (
                <tr key={s.employee.id}>
                  <td className="sticky"><Link to={`/employees/${s.employee.id}`}>{s.employee.full_name}</Link><small>{s.employee.job_role}</small></td>
                  {data.modules.map((m) => {
                    const c = s.cells[m.id];
                    const last = data.logs.find((l) => l.employee_id === s.employee.id && l.module_id === m.id);
                    return <td key={m.id} className="cellc"><Rivet status={c} title={`${s.employee.full_name}, ${m.short_name}: ${c}`}
                      onClick={() => { setInitial(last ? { ...last } : { employee_id: s.employee.id, module_id: m.id }); setOpen(true); }} /></td>;
                  })}
                  <td><b>{s.completed}</b>/{data.modules.length} <small>{Math.round(s.pct * 100)}%</small></td>
                  <td><Pill status={s.overall} /> {s.overdue && <Pill status="Overdue" />}</td>
                  <td>{fmt(s.lastActivity)}</td>
                  <td>{s.avgScore === null ? "-" : `${Math.round(s.avgScore)}%`}</td>
                </tr>
              ))}
              {!rows.length && <tr><td colSpan={data.modules.length + 5} className="muted">No employees match these filters.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
      <LogForm open={open} onClose={() => setOpen(false)} initial={initial} />
    </>
  );
}
