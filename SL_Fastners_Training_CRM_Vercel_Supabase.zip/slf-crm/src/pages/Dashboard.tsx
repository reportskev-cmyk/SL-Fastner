import { useMemo } from "react";
import { Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend } from "recharts";
import { useCrm } from "../lib/data";
import { ROLES, result, summarize } from "../lib/crm";
import { Empty, PageHead } from "../components/ui";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const { data } = useCrm();
  const sums = useMemo(() => data.employees.map((e) => summarize(e, data.modules, data.logs)), [data]);
  const total = sums.length;
  const done = sums.filter((s) => s.overall === "Completed").length;
  const prog = sums.filter((s) => s.overall === "In Progress").length;
  const none = sums.filter((s) => s.overall === "Not Started").length;
  const overdue = sums.filter((s) => s.overdue).length;
  const overall = total && data.modules.length ? sums.reduce((a, s) => a + s.completed, 0) / (total * data.modules.length) : 0;
  const completedLogs = data.logs.filter((l) => l.status === "Completed" && l.score !== null);
  const avg = completedLogs.length ? completedLogs.reduce((a, l) => a + Number(l.score), 0) / completedLogs.length : null;
  const reassess = data.logs.filter((l) => {
    const m = data.modules.find((x) => x.id === l.module_id);
    return m && l.status === "Completed" && result(l.score, m.pass_mark) === "Re-assess";
  }).length;

  const modRows = data.modules.map((m) => {
    const c = sums.filter((s) => s.cells[m.id] === "Completed").length;
    const p = sums.filter((s) => s.cells[m.id] === "In Progress").length;
    return { id: m.id, name: m.short_name, pct: total ? Math.round((c / total) * 100) : 0, completed: c, inProgress: p };
  });
  const roleRows = [...new Set([...ROLES, ...data.employees.map((e) => e.job_role).filter(Boolean) as string[]])].map((r) => {
    const g = sums.filter((s) => s.employee.job_role === r);
    return { role: r, n: g.length, done: g.filter((s) => s.overall === "Completed").length, overdue: g.filter((s) => s.overdue).length,
      avg: g.length ? g.reduce((a, s) => a + s.pct, 0) / g.length : 0 };
  }).filter((r) => r.n);
  const pie = [{ name: "Completed", value: done, c: "#2E7D4F" }, { name: "In Progress", value: prog, c: "#E0A100" }, { name: "Not Started", value: none, c: "#B8BEC9" }];

  if (!total) return (<><PageHead title="Dashboard" /><Empty title="No employees yet" text="Add your sales team to start tracking training.">
    <Link className="btn primary" to="/employees">Add employees</Link></Empty></>);

  const kpis: [string, string | number][] = [
    ["Employees", total], ["Fully completed", done], ["In progress", prog], ["Not started", none], ["Overdue", overdue],
    ["Module completion", `${Math.round(overall * 100)}%`], ["Average score", avg === null ? "-" : `${Math.round(avg)}%`], ["Re-assessments pending", reassess],
  ];
  return (
    <>
      <PageHead title="Dashboard" sub="Training status and module completion across the sales team." />
      <div className="kpis">{kpis.map(([k, v]) => <div key={k} className={`kpi ${k === "Overdue" && overdue ? "alert" : ""}`}><b>{v}</b><span>{k}</span></div>)}</div>
      <div className="two-col wide-left">
        <section className="panel">
          <h3>Completion by module</h3>
          <div style={{ height: 380 }}>
            <ResponsiveContainer>
              <BarChart data={modRows} layout="vertical" margin={{ left: 20, right: 24 }}>
                <XAxis type="number" domain={[0, 100]} tickFormatter={(v) => `${v}%`} />
                <YAxis type="category" dataKey="name" width={150} tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v: number) => `${v}%`} />
                <Bar dataKey="pct" name="Completed" fill="#1F3864" radius={[0, 3, 3, 0]} label={{ position: "right", fontSize: 11, formatter: (v: number) => `${v}%` }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>
        <section className="panel">
          <h3>Employees by status</h3>
          <div style={{ height: 260 }}>
            <ResponsiveContainer>
              <PieChart><Pie data={pie} dataKey="value" nameKey="name" innerRadius={60} outerRadius={95} paddingAngle={2}>{pie.map((p) => <Cell key={p.name} fill={p.c} />)}</Pie>
                <Tooltip /><Legend /></PieChart>
            </ResponsiveContainer>
          </div>
          <h3 className="space-top">By role</h3>
          <div className="table-wrap"><table><thead><tr><th>Role</th><th>Staff</th><th>Done</th><th>Overdue</th><th>Avg</th></tr></thead>
            <tbody>{roleRows.map((r) => <tr key={r.role}><td>{r.role}</td><td>{r.n}</td><td>{r.done}</td><td>{r.overdue}</td><td>{Math.round(r.avg * 100)}%</td></tr>)}</tbody></table></div>
        </section>
      </div>
    </>
  );
}
