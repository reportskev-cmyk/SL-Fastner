import { FormEvent, useState } from "react";
import { supabase } from "../lib/supabase";
import { useCrm } from "../lib/data";
import { COMPETENCIES, RATING_GUIDE, fmt, needsCoaching, scoreTotal } from "../lib/crm";
import { Modal, PageHead } from "../components/ui";

export default function Scorecards() {
  const { data, refresh } = useCrm();
  const [open, setOpen] = useState(false);
  const [empId, setEmpId] = useState(""); const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [by, setBy] = useState(""); const [scores, setScores] = useState<number[]>(Array(8).fill(3)); const [action, setAction] = useState("");
  const [err, setErr] = useState("");
  const name = (id: string) => data.employees.find((e) => e.id === id)?.full_name ?? "-";

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!empId) { setErr("Choose an employee."); return; }
    if (needsCoaching(scores) && !action.trim()) { setErr("A competency is scored 1 or 2. Add a coaching action."); return; }
    const { error } = await supabase.from("scorecards").insert({ employee_id: empId, eval_date: date, evaluator: by || null, scores, coaching_action: action || null });
    if (error) { setErr(error.message); return; }
    await refresh(); setOpen(false); setScores(Array(8).fill(3)); setAction(""); setErr("");
  }
  async function remove(id: string) { if (confirm("Delete this scorecard?")) { await supabase.from("scorecards").delete().eq("id", id); await refresh(); } }

  return (
    <>
      <PageHead title="Manager scorecard" sub={`Score each competency from 1 to 5. ${RATING_GUIDE.map((g, i) => `${i + 1} ${g}`).join(", ")}.`}>
        <button className="btn primary" onClick={() => { setErr(""); setOpen(true); }}>New scorecard</button>
      </PageHead>
      <div className="table-wrap"><table>
        <thead><tr><th>Employee</th><th>Date</th><th>Evaluator</th>{COMPETENCIES.map((_, i) => <th key={i} title={COMPETENCIES[i]}>C{i + 1}</th>)}<th>Total / 40</th><th>Coaching</th><th /></tr></thead>
        <tbody>{data.scorecards.map((s) => (
          <tr key={s.id}><td>{name(s.employee_id)}</td><td>{fmt(s.eval_date)}</td><td>{s.evaluator ?? "-"}</td>
            {s.scores.map((v, i) => <td key={i} className={v <= 2 ? "low-cell" : ""}>{v}</td>)}
            <td><b>{scoreTotal(s.scores)}</b></td><td>{needsCoaching(s.scores) ? (s.coaching_action || "Required") : "No"}</td>
            <td><button className="btn small danger-ghost" onClick={() => remove(s.id)}>Delete</button></td></tr>))}
          {!data.scorecards.length && <tr><td colSpan={14} className="muted">No scorecards yet.</td></tr>}</tbody></table></div>
      <p className="muted small">C1 to C8 follow the manual: {COMPETENCIES.map((c, i) => `C${i + 1} ${c}`).join("; ")}.</p>
      <Modal open={open} onClose={() => setOpen(false)} title="New scorecard" wide>
        <form className="form-grid" onSubmit={save}>
          <label>Employee<select value={empId} onChange={(e) => setEmpId(e.target.value)}><option value="">Select employee</option>{data.employees.map((e) => <option key={e.id} value={e.id}>{e.full_name}</option>)}</select></label>
          <label>Date<input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
          <label>Evaluator<input value={by} onChange={(e) => setBy(e.target.value)} /></label>
          <span />
          {COMPETENCIES.map((c, i) => (
            <label key={c}>{c}<select value={scores[i]} onChange={(e) => setScores((p) => p.map((v, j) => (j === i ? Number(e.target.value) : v)))}>
              {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n} - {RATING_GUIDE[n - 1]}</option>)}</select></label>))}
          <p className="full"><b>Total: {scoreTotal(scores)} / 40</b>{needsCoaching(scores) && " (coaching action needed)"}</p>
          <label className="full">Coaching action<textarea rows={2} value={action} onChange={(e) => setAction(e.target.value)} /></label>
          {err && <p className="error full">{err}</p>}
          <div className="form-actions full"><span className="grow" /><button type="button" className="btn ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn primary">Save scorecard</button></div>
        </form>
      </Modal>
    </>
  );
}
