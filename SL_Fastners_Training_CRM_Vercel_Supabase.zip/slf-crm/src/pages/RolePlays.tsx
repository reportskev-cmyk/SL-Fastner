import { FormEvent, useState } from "react";
import { supabase } from "../lib/supabase";
import { useCrm } from "../lib/data";
import { RP_CHECKS, SCENARIOS, fmt, rpScore } from "../lib/crm";
import { Modal, PageHead } from "../components/ui";

export default function RolePlays() {
  const { data, refresh } = useCrm();
  const [open, setOpen] = useState(false);
  const [empId, setEmpId] = useState(""); const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [scn, setScn] = useState(SCENARIOS[0]); const [obs, setObs] = useState(""); const [checks, setChecks] = useState<boolean[]>(Array(6).fill(false));
  const [remarks, setRemarks] = useState(""); const [err, setErr] = useState("");
  const name = (id: string) => data.employees.find((e) => e.id === id)?.full_name ?? "-";

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!empId) { setErr("Choose an employee."); return; }
    const { error } = await supabase.from("roleplays").insert({ employee_id: empId, rp_date: date, scenario: scn, observer: obs || null, checks, remarks: remarks || null });
    if (error) { setErr(error.message); return; }
    await refresh(); setOpen(false); setChecks(Array(6).fill(false)); setRemarks(""); setErr("");
  }
  async function remove(id: string) { if (confirm("Delete this role-play?")) { await supabase.from("roleplays").delete().eq("id", id); await refresh(); } }

  return (
    <>
      <PageHead title="Role-play log" sub="Observer checklist from the manual. Score is the number of Yes answers out of 6.">
        <button className="btn primary" onClick={() => { setErr(""); setOpen(true); }}>Log role-play</button>
      </PageHead>
      <div className="table-wrap"><table>
        <thead><tr><th>Date</th><th>Employee</th><th>Scenario</th><th>Observer</th>{RP_CHECKS.map((c, i) => <th key={i} title={c}>Q{i + 1}</th>)}<th>Score / 6</th><th>Remarks</th><th /></tr></thead>
        <tbody>{data.roleplays.map((r) => (
          <tr key={r.id}><td>{fmt(r.rp_date)}</td><td>{name(r.employee_id)}</td><td>{r.scenario}</td><td>{r.observer ?? "-"}</td>
            {r.checks.map((c, i) => <td key={i} className={c ? "" : "low-cell"}>{c ? "Yes" : "No"}</td>)}
            <td><b>{rpScore(r)}</b></td><td>{r.remarks ?? ""}</td><td><button className="btn small danger-ghost" onClick={() => remove(r.id)}>Delete</button></td></tr>))}
          {!data.roleplays.length && <tr><td colSpan={13} className="muted">No role-plays logged yet.</td></tr>}</tbody></table></div>
      <p className="muted small">{RP_CHECKS.map((c, i) => `Q${i + 1} ${c}`).join("; ")}.</p>
      <Modal open={open} onClose={() => setOpen(false)} title="Log role-play">
        <form className="form-grid" onSubmit={save}>
          <label>Employee<select value={empId} onChange={(e) => setEmpId(e.target.value)}><option value="">Select employee</option>{data.employees.map((e) => <option key={e.id} value={e.id}>{e.full_name}</option>)}</select></label>
          <label>Date<input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
          <label>Scenario<select value={scn} onChange={(e) => setScn(e.target.value)}>{SCENARIOS.map((s) => <option key={s}>{s}</option>)}</select></label>
          <label>Observer<input value={obs} onChange={(e) => setObs(e.target.value)} /></label>
          <div className="full checks">{RP_CHECKS.map((c, i) => <label key={c} className="check"><input type="checkbox" checked={checks[i]} onChange={(e) => setChecks((p) => p.map((v, j) => (j === i ? e.target.checked : v)))} /> {c}</label>)}</div>
          <p className="full"><b>Score: {checks.filter(Boolean).length} / 6</b></p>
          <label className="full">Observer remarks<textarea rows={2} value={remarks} onChange={(e) => setRemarks(e.target.value)} /></label>
          {err && <p className="error full">{err}</p>}
          <div className="form-actions full"><span className="grow" /><button type="button" className="btn ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn primary">Save role-play</button></div>
        </form>
      </Modal>
    </>
  );
}
