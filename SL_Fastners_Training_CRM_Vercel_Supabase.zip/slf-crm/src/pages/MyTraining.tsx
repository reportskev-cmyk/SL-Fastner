import { useCrm } from "../lib/data";
import { Empty, PageHead } from "../components/ui";
import EmployeeView from "../components/EmployeeView";

export default function MyTraining() {
  const { me } = useCrm();
  if (!me?.employee) return (<><PageHead title="My training" /><Empty title="Your account is not linked to a training record yet"
    text={`Ask your manager to register ${me?.email ?? "your email"} under Employees. It will link automatically.`} /></>);
  return (<><PageHead title="My training" sub="Your progress across all modules." /><EmployeeView employee={me.employee} canEdit={false} /></>);
}
