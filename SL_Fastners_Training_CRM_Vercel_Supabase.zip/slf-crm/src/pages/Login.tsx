import { FormEvent, useState } from "react";
import { supabase, configured } from "../lib/supabase";

export default function Login() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMsg("");
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMsg(error.message);
    } else {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: name } } });
      if (error) setMsg(error.message);
      else if (!data.session) setMsg("Account created. Check your email to confirm it, then sign in.");
    }
    setBusy(false);
  }

  return (
    <div className="login">
      <div className="login-art">
        <h1>SL Fastners</h1>
        <p>Sales training tracker</p>
        <div className="rivets" aria-hidden="true">{Array.from({ length: 13 }).map((_, i) => <i key={i} className={i < 8 ? "s-done" : i < 10 ? "s-prog" : "s-none"} />)}</div>
        <p className="small">13 modules from first customer call to closed order.</p>
      </div>
      <form className="login-card" onSubmit={submit}>
        <h2>{mode === "in" ? "Sign in" : "Create your account"}</h2>
        {!configured && <p className="error">Supabase is not configured. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.</p>}
        {mode === "up" && <label>Full name<input value={name} onChange={(e) => setName(e.target.value)} required /></label>}
        <label>Work email<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" /></label>
        <label>Password<input type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required autoComplete={mode === "in" ? "current-password" : "new-password"} /></label>
        {msg && <p className="error">{msg}</p>}
        <button className="btn primary block" disabled={busy}>{busy ? "Please wait..." : mode === "in" ? "Sign in" : "Create account"}</button>
        <button type="button" className="link" onClick={() => { setMode(mode === "in" ? "up" : "in"); setMsg(""); }}>
          {mode === "in" ? "First time here? Create an account" : "Already registered? Sign in"}
        </button>
        {mode === "up" && <p className="small muted">Use the email your manager registered. It links your account to your training record.</p>}
      </form>
    </div>
  );
}
