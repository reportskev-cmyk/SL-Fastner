-- SL Fastners Training CRM - run once in Supabase: SQL Editor > New query > paste > Run
create type public.app_role as enum ('admin','employee');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  created_at timestamptz not null default now()
);
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  unique (user_id, role)
);
create table public.employees (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  emp_code text,
  full_name text not null,
  email text not null unique,
  job_role text,
  department text,
  region text,
  reporting_manager text,
  mobile text,
  joining_date date,
  batch text,
  target_date date,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.modules (
  id text primary key,
  sort int not null,
  title text not null,
  short_name text not null,
  phase text,
  key_output text,
  assessment text,
  pass_mark int not null default 70 check (pass_mark between 0 and 100)
);
create table public.training_logs (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.employees(id) on delete cascade,
  module_id text not null references public.modules(id) on delete cascade,
  session_date date not null default current_date,
  trainer text,
  mode text not null default 'Classroom',
  attended boolean not null default true,
  status text not null default 'Scheduled'
    check (status in ('Scheduled','In Progress','Completed','Missed - Reschedule')),
  score numeric check (score is null or (score >= 0 and score <= 100)),
  remarks text,
  created_at timestamptz not null default now()
);
create index on public.training_logs (employee_id, module_id);
create table public.scorecards (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.employees(id) on delete cascade,
  eval_date date not null default current_date,
  evaluator text,
  scores int[] not null check (array_length(scores,1) = 8),
  coaching_action text,
  created_at timestamptz not null default now()
);
create table public.roleplays (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.employees(id) on delete cascade,
  rp_date date not null default current_date,
  scenario text not null,
  observer text,
  checks boolean[] not null check (array_length(checks,1) = 6),
  remarks text,
  created_at timestamptz not null default now()
);
create table public.plan_progress (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.employees(id) on delete cascade,
  period int not null check (period between 1 and 6),
  status text not null default 'Not Started' check (status in ('Not Started','In Progress','Done')),
  notes text,
  unique (employee_id, period)
);

-- Access
grant select, update on public.profiles to authenticated;
grant select on public.user_roles to authenticated;
grant select, insert, update, delete on public.employees, public.modules, public.training_logs,
  public.scorecards, public.roleplays, public.plan_progress to authenticated;

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.employees enable row level security;
alter table public.modules enable row level security;
alter table public.training_logs enable row level security;
alter table public.scorecards enable row level security;
alter table public.roleplays enable row level security;
alter table public.plan_progress enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;
create or replace function public.is_own_employee(_employee_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.employees where id = _employee_id and user_id = auth.uid())
$$;

create policy "profile read" on public.profiles for select to authenticated
  using (id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "profile update" on public.profiles for update to authenticated using (id = auth.uid());
create policy "roles read" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

create policy "modules read" on public.modules for select to authenticated using (true);
create policy "modules admin" on public.modules for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create policy "employees read" on public.employees for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "employees admin" on public.employees for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create policy "logs read" on public.training_logs for select to authenticated
  using (public.is_own_employee(employee_id) or public.has_role(auth.uid(),'admin'));
create policy "logs admin" on public.training_logs for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "score read" on public.scorecards for select to authenticated
  using (public.is_own_employee(employee_id) or public.has_role(auth.uid(),'admin'));
create policy "score admin" on public.scorecards for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "rp read" on public.roleplays for select to authenticated
  using (public.is_own_employee(employee_id) or public.has_role(auth.uid(),'admin'));
create policy "rp admin" on public.roleplays for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "plan read" on public.plan_progress for select to authenticated
  using (public.is_own_employee(employee_id) or public.has_role(auth.uid(),'admin'));
create policy "plan admin" on public.plan_progress for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- New sign-up: create profile, first user becomes admin, link to employee record by email
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform pg_advisory_xact_lock(4242);
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)));
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  else
    insert into public.user_roles (user_id, role) values (new.id, 'employee');
  end if;
  update public.employees set user_id = new.id where lower(email) = lower(new.email) and user_id is null;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- When admin adds an employee whose email already has an account, link it
create or replace function public.link_employee_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.user_id is null then
    select id into new.user_id from public.profiles where lower(email) = lower(new.email) limit 1;
  end if;
  return new;
end $$;
create trigger employees_link before insert or update of email on public.employees
  for each row execute function public.link_employee_user();

-- The 13 modules from the SL Fastners training manual
insert into public.modules (id, sort, title, short_name, phase, key_output, assessment) values
('M01',1,'Understand the Product Before Selling','Product Knowledge','Day 1','Customer/application discovery checklist','Product knowledge quiz'),
('M02',2,'Understand the Customer and Buying Process','Customer & Buying Process','Day 1','Qualified opportunity profile','Customer profile exercise (8 qualification questions)'),
('M03',3,'The L-A-Q-R-C Objection Handling Method','L-A-Q-R-C Method','Day 1','Consistent response framework','Observed role-play against L-A-Q-R-C steps'),
('M04',4,'Commercial Objections: Scripts and Sales Actions','Commercial Objections','Day 1','Price/value conversation practice','Script role-play on commercial objections'),
('M05',5,'Technical Objections and Complaint Diagnosis','Technical Objections','Day 2','Technical issue capture sheet','Complaint capture form exercise'),
('M06',6,'Segment-Specific Selling Playbook','Segment Playbook','Day 2','Segment-specific approach','Segment discovery quiz'),
('M07',7,'Price Negotiation and Margin Discipline','Price Negotiation','Day 1','Price/value conversation practice','Negotiation role-play (trade value, not price)'),
('M08',8,'Sales Conversation Scripts','Conversation Scripts','Day 2','Next-step action plan','Script practice: first call, sample, quotation, lost-order calls'),
('M09',9,'Follow-Up Discipline and Opportunity Management','Follow-Up & Pipeline','Day 2','Next action, owner and due date on every opportunity','CRM / pipeline audit by manager'),
('M10',10,'Role-Play Workshop','Role-Play Workshop','Day 1-2','Individual coaching points; scorecard and 30-day plan','Observer checklist (6 points)'),
('M11',11,'Sales Manager Evaluation Scorecard','Manager Scorecard','Day 2','Individual scorecard (out of 40)','Manager scores 8 competencies'),
('M12',12,'Sales KPIs and Review Rhythm','KPIs & Reviews','Post-workshop','KPI definitions understood; review rhythm adopted','Manager review of KPI understanding'),
('M13',13,'Worksheets and Field Templates','Worksheets & Templates','Post-workshop (30 days)','Completed field templates on live opportunities','Manager audit of templates and CRM notes');

-- Lock down helper functions (they run inside triggers / access rules only)
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.link_employee_user() from public, anon, authenticated;
revoke execute on function public.has_role(uuid, public.app_role) from public, anon;
revoke execute on function public.is_own_employee(uuid) from public, anon;
grant execute on function public.has_role(uuid, public.app_role) to authenticated;
grant execute on function public.is_own_employee(uuid) to authenticated;
