-- OPTIONAL: sample data to explore the CRM. Run after schema.sql.
insert into public.employees (emp_code, full_name, email, job_role, department, region, reporting_manager, batch, target_date, is_demo) values
('SLF-101','Rohan Mehta','rohan.mehta@demo.slfastners.in','Sales Executive','Sales','North','Suresh Iyer','Batch A', current_date + 20, true),
('SLF-102','Priya Nair','priya.nair@demo.slfastners.in','Sales Executive','Sales','South','Suresh Iyer','Batch A', current_date - 5, true),
('SLF-103','Arjun Singh','arjun.singh@demo.slfastners.in','Territory Manager','Sales','West','Suresh Iyer','Batch A', current_date - 5, true),
('SLF-104','Kavita Rao','kavita.rao@demo.slfastners.in','Sales Leader','Sales','South','Anita Desai','Batch B', current_date + 20, true),
('SLF-105','Imran Khan','imran.khan@demo.slfastners.in','Sales Executive','Sales','North','Anita Desai','Batch B', current_date - 5, true),
('SLF-106','Sneha Patil','sneha.patil@demo.slfastners.in','Sales Coordinator','Sales','West','Anita Desai','Batch B', current_date + 20, true),
('SLF-107','Vikram Joshi','vikram.joshi@demo.slfastners.in','Territory Manager','Sales','East','Anita Desai','Batch C', current_date + 40, true),
('SLF-108','Neha Gupta','neha.gupta@demo.slfastners.in','Sales Coordinator','Sales','East','Anita Desai','Batch C', current_date + 40, true);

with prog(code, done) as (values
  ('SLF-101',13),('SLF-102',10),('SLF-103',7),('SLF-104',13),('SLF-105',4),('SLF-106',2),('SLF-107',0),('SLF-108',9))
insert into public.training_logs (employee_id, module_id, session_date, trainer, mode, attended, status, score)
select e.id, m.id, current_date - 40 + m.sort * 2, 'Scaleup Trainer', 'Classroom', true,
       case when m.sort <= p.done then 'Completed' else 'In Progress' end,
       case when m.sort <= p.done and m.sort <= 9 then 55 + ((m.sort * 7 + length(e.full_name) * 3) % 40) end
from public.employees e
join prog p on p.code = e.emp_code
join public.modules m on m.sort <= p.done or (m.sort = p.done + 1 and p.done between 1 and 12)
where e.is_demo;

insert into public.scorecards (employee_id, eval_date, evaluator, scores, coaching_action)
select id, current_date - 7, 'Suresh Iyer', array[4,4,3,4,3,3,4,3], null from public.employees where emp_code in ('SLF-101','SLF-104')
union all
select id, current_date - 7, 'Suresh Iyer', array[3,4,2,3,3,2,3,3], 'Practise acknowledging concerns before responding' from public.employees where emp_code = 'SLF-103';

insert into public.roleplays (employee_id, rp_date, scenario, observer, checks, remarks)
select id, current_date - 10, 'Price pressure', 'Anita Desai', array[true,true,true,true,true,false], 'Fix a date for the trial' from public.employees where emp_code in ('SLF-101','SLF-102','SLF-103');

insert into public.plan_progress (employee_id, period, status)
select e.id, p, case when p <= 3 then 'Done' when p = 4 then 'In Progress' else 'Not Started' end
from public.employees e, generate_series(1,6) p where e.emp_code in ('SLF-101','SLF-104');
-- To remove all demo data later:  delete from public.employees where is_demo;
