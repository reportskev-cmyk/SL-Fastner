# SL Fastners Training CRM

Web app (React + Vite) on Supabase, deployable on Vercel. Tracks employee training status and completion of the
13 modules from the SL Fastners Sales Training Manual. Admins manage everything; employees sign in and see only their own progress.

## 1. Supabase database
(Already created and set up for you: project `sl-fastners-training-crm`, ref `iqssscaiwdkkuuofllth`, region Mumbai. `.env.example` holds its URL and public key.)
To use a different project instead:
1. Create a project at supabase.com.
2. SQL Editor > New query > paste `supabase/schema.sql` > Run.
3. (Optional) run `supabase/demo_data.sql` for sample employees. Remove later with `delete from public.employees where is_demo;`
4. Authentication > Providers > Email: for a quick start turn OFF "Confirm email" (or keep it on and have users confirm by email).
5. Project Settings > API: copy the Project URL and the anon public key.

## 2. Run locally (optional)
    cp .env.example .env     # paste the URL and anon key
    npm install
    npm run dev

## 3. Deploy on Vercel
1. Push this folder to a GitHub repository.
2. Vercel > Add New Project > import the repo (framework: Vite, auto-detected).
3. Add environment variables `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. Deploy. Then in Supabase: Authentication > URL Configuration > set Site URL to your Vercel URL.

## 4. First use
1. Open the Vercel link and Create account. **The first account created becomes the administrator**, so do this yourself before sharing the link.
2. Employees page > Add employee (use each person's work email).
3. Share the link. Each employee creates an account with the same email and is linked to their record automatically.
4. Training log: add a record after each session. Tracker, Dashboard, Scorecards, Role-plays and the 30-day plan update from your entries.

## Security notes
- The anon key is safe in the browser because Row Level Security restricts every table. Never put the service_role key in this app.
- Admin rights live in the `user_roles` table and cannot be set from the app.
